package com.example.knk.topm.Object;

public class InputException extends Exception {

}
